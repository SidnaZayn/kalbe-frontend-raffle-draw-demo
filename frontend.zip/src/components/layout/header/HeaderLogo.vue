<template>
  <router-link to="/" class="lg:hidden">
    <img class="dark:hidden" src="/Kalbe_Farma_min.png" width="30" alt="Logo" />
    <img class="hidden dark:block" src="/Kalbe_Farma_min.png" width="30" alt="Logo" />
  </router-link>
</template>

<script setup lang="ts">
import { RouterLink } from 'vue-router'
</script>
