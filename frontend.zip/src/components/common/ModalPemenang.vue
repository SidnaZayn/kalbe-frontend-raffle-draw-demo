<template>
    <div class="fixed inset-0 z-20 flex items-center justify-center bg-black/25" @click.self="$emit('closeModal')">
        <div class="bg-[url('@/assets/Rectangle-12.png')] bg-cover bg-center bg-no-repeat rounded-lg shadow-lg p-6 w-[60vw]"
            @click.stop>
            <h2 class="text-xl font-semibold mb-4">{{ title }}</h2>
            <slot></slot>
            <div class="mt-4 flex justify-center">
                <button class="px-4 py-2 bg-red-500 text-white rounded dark:bg-red-600 mr-2"
                    @click="$emit('confirmAction')" :disabled="confirmStatus">
                    {{ confirm }}
                </button>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { defineProps } from 'vue'
defineProps({
    title: {
        type: String,
        default: 'Modal Title'
    },
    confirm: {
        type: String,
        default: 'Confirm'
    },
    confirmStatus: {
        type: Boolean,
        default: false
    }
})
</script>