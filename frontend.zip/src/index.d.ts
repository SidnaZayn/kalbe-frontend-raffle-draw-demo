declare module 'jsvectormap'
declare module "@tsparticles/vue3"